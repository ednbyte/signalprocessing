# Wave Detect - Signal Processing & Detection 

Correlation-based detection system for identifying embedded signals in noisy environments.


![reults0 9](https://github.com/user-attachments/assets/8ad1a13a-0d3e-468c-b2f5-b4b30225e7a0)
